import cv2
import tkinter as tk
from PIL import Image, ImageTk
import numpy as np 

# Function to determine the color at a specific point
def get_color(frame, x, y):
    # Extract region around centroid for color detection
    region = frame[max(y - 5, 0):min(y + 5, frame.shape[0]), max(x - 5, 0):min(x + 5, frame.shape[1])]
    # Check if region is valid
    if region.size == 0:
        return ""
    # Convert region to HSV color space
    hsv = cv2.cvtColor(region, cv2.COLOR_BGR2HSV)
    # Define lower and upper bounds for red color
    lower_red1 = np.array([0, 70, 50])
    upper_red1 = np.array([10, 255, 255])
    lower_red2 = np.array([160, 70, 50])
    upper_red2 = np.array([180, 255, 255])
    lower_yellow = np.array([20, 100, 100])
    upper_yellow = np.array([30, 255, 255])
    # Define lower and upper bounds for green color
    lower_green1 = np.array([30, 70, 50])
    upper_green1 = np.array([90, 255, 255])
    lower_green2 = np.array([71, 70, 50])
    upper_green2 = np.array([80, 255, 255])
    lower_black = np.array([0, 0, 0])
    upper_black = np.array([179, 50, 30])
    # Threshold the HSV image to get only red or green colors
    mask_red1 = cv2.inRange(hsv, lower_red1, upper_red1)
    mask_red2 = cv2.inRange(hsv, lower_red2, upper_red2)
    mask_red = cv2.bitwise_or(mask_red1, mask_red2)
    mask_yellow = cv2.inRange(hsv, lower_yellow, upper_yellow)
    mask_green1 = cv2.inRange(hsv, lower_green1, upper_green1)
    mask_green2 = cv2.inRange(hsv, lower_green2, upper_green2)
    mask_green = cv2.bitwise_or(mask_green1, mask_green2)
    mask_black = cv2.inRange(hsv, lower_black, upper_black)
    # Check if red or green color is present in the region
    if cv2.countNonZero(mask_yellow) > 0:
        return "X"
    elif cv2.countNonZero(mask_green) > 0:
        return "O"
    else:
        return ""

# Create Tkinter window
root = tk.Tk()
root.title("Tic Tac Toe")

# Create a 3x3 grid of labels
labels = [[tk.Label(root, width=10, height=5, borderwidth=2, relief="ridge") for _ in range(3)] for _ in range(3)]

def update_gui():
    # Read frame from camera
    ret, frame = cap.read()
    if ret:
        frame = cv2.rotate(frame, cv2.ROTATE_90_CLOCKWISE)
    else:
        return

    # Convert frame to grayscale
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

    # Apply Gaussian blur to reduce noise
    blurred = cv2.GaussianBlur(gray, (5, 5), 0)

    # Apply Canny edge detection
    edges = cv2.Canny(blurred, 50, 150, apertureSize=3)

    # Find contours
    contours, _ = cv2.findContours(edges.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    # Draw bounding boxes and extract coordinates
    for i, contour in enumerate(contours):
        if i < 9:
            x, y, w, h = cv2.boundingRect(contour)
            center_x = x + w // 2
            center_y = y + h // 2
            # Determine row and column based on center coordinates
            row = int((center_y / frame.shape[0]) * 3)
            col = int((center_x / frame.shape[1]) * 3)

            color = get_color(frame, center_x, center_y)
            labels[row][col].config(text=color)
            cv2.putText(frame, color, (center_x - 10, center_y + 10), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)

    # Update GUI
    root.after(10, update_gui)

    # Display the frame
    frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    img = Image.fromarray(frame)
    imgtk = ImageTk.PhotoImage(image=img)
    label.imgtk = imgtk
    label.configure(image=imgtk)

# Capture live video from camera
cap = cv2.VideoCapture(4)  # Use appropriate camera index, 0 is usually the default webcam

# Check if the camera is opened successfully
if cap.isOpened():
    # Place labels in the grid
    for i in range(3):
        for j in range(3):
            labels[i][j].grid(row=i, column=j, padx=5, pady=5)

    # Create label for displaying camera feed
    label = tk.Label(root)
    label.grid(row=3, columnspan=3)

    # Start updating GUI
    update_gui()

    # Start Tkinter event loop
    root.mainloop()

    # Release the camera
    cap.release()
else:
    print("Failed to open camera.")
