import cv2
import numpy as np
import random
import tkinter as tk
from tkinter import messagebox
import pickle
from PIL import Image, ImageTk
from interbotix_xs_modules.arm import InterbotixManipulatorXS
import time
 
bot = InterbotixManipulatorXS("wx200", "arm", "gripper")
 
 
Q_FILE = "q_table.pkl"
 
alpha = 0.5
gamma = 0.9
min_epsilon = 0.01
min_alpha = 0.001
epsilon = 1.0
no_of_games = 200000
 
turn = ' '
X_wins = 0
O_wins = 0
draws = 0
 
def get_epsilon():
    if not hasattr(get_epsilon, "counter"):
        get_epsilon.counter = 0
    get_epsilon.counter += 1
    m = epsilon // no_of_games
    return epsilon - (m * get_epsilon.counter)
 
def get_alpha():
    if not hasattr(get_alpha, "counter"):
        get_alpha.counter = 0
    m = alpha // no_of_games
    return alpha - (m * get_alpha.counter)
 
def new_game():
    board = []
    for _ in range(9):
        board.append(' ')
    return board
 
def check_game_over(board):
    combinations = ((0, 1, 2), (3, 4, 5), (6, 7, 8), (0, 3, 6),
                    (1, 4, 7), (2, 5, 8), (0, 4, 8), (2, 4, 6))
    for i in combinations:
        if board[i[0]] == board[i[1]] == board[i[2]] != ' ':
            return board[i[0]]
    if ' ' not in board:
        return 'TIE'
    else:
        return 'Not over'
 
def get_available_actions(board):
    available_actions = []
    for i in range(0, 9):
        if board[i] == ' ':
            available_actions.append(i)
    return available_actions
 
def get_Q(board, action):
    b = tuple(board)
    if Q.get((b, action)) is None:
        Q[(b, action)] = 0
    return Q[(b, action)]
 
def get_best_move(board, turn, human=False):
    actions = get_available_actions(board)
    eps = get_epsilon()
    if random.uniform(0, 1) < eps and human is False:
        return random.choice(actions)
    qs = [get_Q(board, action) for action in actions]
    print("qs is ",qs)
    if turn == 'X':
        max_or_minQ = max(qs)
    else:
        max_or_minQ = min(qs)
 
    best_actions = [actions[i] for i in range(len(actions)) if qs[i] == max_or_minQ]
    print("best actions : ",best_actions)
 
    return random.choice(best_actions)
 
def get_box_name(row, col):
    if 0 <= row < 3 and 0 <= col < 3:
        return str(col + row * 3)
    else:
        return "Invalid Index"
 
# Function to determine the color of an object based on its centroid
def get_color(frame, x, y):
    # Extract region around centroid for color detection
    region = frame[y - 5:y + 5, x - 5:x + 5]
    # Convert region to HSV color space
    hsv = cv2.cvtColor(region, cv2.COLOR_BGR2HSV)
    # Define lower and upper bounds for green color
    lower_green = np.array([40, 40, 40])
    upper_green = np.array([80, 255, 255])
    lower_yellow = np.array([20, 100, 100])
    upper_yellow = np.array([30, 255, 255])
    # Threshold the HSV image to get only green color
    mask_green = cv2.inRange(hsv, lower_green, upper_green)
    mask_yellow = cv2.inRange(hsv, lower_yellow, upper_yellow)
    # Check if green color is present in the region
    if cv2.countNonZero(mask_green) > 0:
        return "O"
    elif cv2.countNonZero(mask_yellow) > 0:
        return "X"
    else:
        return ""
 
def save_q_table(Q):
    with open(Q_FILE, 'wb') as file:
        pickle.dump(Q, file)
 
def load_q_table():
    try:
        with open(Q_FILE, 'rb') as file:
            return pickle.load(file)
    except FileNotFoundError:
        return {}
 
class TicTacToeGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Tic-Tac-Toe")
        self.board = new_game()
        self.turn = 'X'
 
        self.Q = load_q_table()
 
        self.buttons = []
        for row in range(3):
            button_row = []
            for col in range(3):
                button = tk.Button(root, text="", font=('consolas', 20), width=5, height=2,
                                   command=lambda row=row, col=col: self.make_move(row, col))
                button.grid(row=row, column=col)
                button_row.append(button)
            self.buttons.append(button_row)
 
        self.canvas = tk.Canvas(root, width=640, height=480)  # Adjust dimensions as needed
        self.canvas.grid(row=3, column=0, columnspan=3)
 
        # Start the game with a move by the computer
        # self.make_computer_move_with_delay()
 
    def make_computer_move_with_delay(self):
        # Delay for 1 second
        time.sleep(1)
        # self.make_computer_move()
 
    # def make_move(self, row, col):
    #     if self.board[row * 3 + col] == ' ':
    #         self.board[row * 3 + col] = self.turn
    #         self.buttons[row][col]['text'] = self.turn
    #         self.check_winner()
    #         self.switch_turn()
    #         self.make_computer_move_with_delay()
    #         # Make a move by the computer if the game is not over
    #         if check_game_over(self.board) == 'Not over' and self.turn == 'O':
    #             self.make_computer_move()
    #             self.make_computer_move_with_delay()
    #         # self.switch_turn()
 
    def make_move(self, row, col):
     if self.board[row * 3 + col] == ' ':
        self.board[row * 3 + col] = self.turn
        self.buttons[row][col]['text'] = self.turn
        self.check_winner()
        self.switch_turn()
        # Check if it's the robotic arm's turn ('O') and the game is not over
        if self.turn == 'O' and check_game_over(self.board) == 'Not over':
            self.make_computer_move_with_delay()  # Make a move by the robotic arm

    def make_computer_move(self):
        if check_game_over(self.board) == 'Not over' and self.turn == 'O':
            computer_move = get_best_move(self.board, self.turn, human=False)
            print("computer_move : ",computer_move)
            # row, col = divmod(computer_move, 3)
            row=0
            col=0
            if computer_move == 2:
                print("@@@@@")
                row = 2
                col = 0
            if computer_move == 0:
                print("@@@@@")
                row = 2
                col = 2
            if computer_move == 1:
                print("@@@@@")
                row = 2
                col = 1
            if computer_move == 3:
                print("@@@@@")
                row = 1
                col = 0
            if computer_move == 4:
                print("@@@@@")
                row = 1
                col = 1
            if computer_move == 5:
                print("@@@@@")
                row = 1
                col = 2
            if computer_move == 6:
                print("@@@@@")
                row = 0
                col = 0
            if computer_move == 7:
                print("@@@@@")
                row = 0
                col = 1
            if computer_move == 8:
                print("@@@@@")
                row = 0
                col = 2
            print("row-O ", row, "col-O ", col)
            self.make_move(row, col)
            save_q_table(self.Q)  # Save Q-table after each move
            print("computer_move", computer_move)
            if computer_move==0:
                # bot.arm.go_to_home_pose()
                bot.arm.set_ee_pose_components(0.17, -0.18, -0.081, 1, 1.5)
                bot.gripper.close()
                bot.gripper.set_pressure(1.0)
                # bot.arm.go_to_home_pose()
                bot.arm.set_ee_pose_components(0.17, -0.18, 0.081, 1, 1.5)
                bot.arm.set_ee_pose_components(0.18, 0.02, 0.084, 1, 1.5)
                bot.arm.set_ee_pose_components(0.18, 0.02, -0.084, 1, 1.5)
                bot.gripper.open()
                # bot.arm.go_to_home_pose()
                bot.arm.go_to_sleep_pose()
            elif computer_move==1:
                # bot.arm.go_to_home_pose()
                bot.arm.set_ee_pose_components(0.24, -0.18, -0.081, 1, 1.5)
                bot.gripper.close()
                bot.gripper.set_pressure(1.0)
                # bot.arm.go_to_home_pose()
                bot.arm.set_ee_pose_components(0.24, -0.18, 0.081, 1, 1.5)
                bot.arm.set_ee_pose_components(0.24, 0.02, 0.084, 1, 1.5)
                bot.arm.set_ee_pose_components(0.24, 0.02, -0.084, 1, 1.5)
                bot.gripper.open()
                # bot.arm.go_to_home_pose()
                bot.arm.go_to_sleep_pose()
            elif computer_move==2:
                # bot.arm.go_to_home_pose()
                bot.arm.set_ee_pose_components(0.30, -0.18, -0.081, 0.8, 1.5)
                bot.gripper.close()
                bot.gripper.set_pressure(1.0)
                # bot.arm.go_to_home_pose()
                bot.arm.set_ee_pose_components(0.30, -0.18, 0.081, 0.8, 1.5)
                bot.arm.set_ee_pose_components(0.30, 0.02, 0.084, 1, 1.5)
                bot.arm.set_ee_pose_components(0.30, 0.02, -0.084, 1, 1.5)
                bot.gripper.open()
                # bot.arm.go_to_home_pose()
                bot.arm.go_to_sleep_pose()
            elif computer_move==3:
                # bot.arm.go_to_home_pose()
                bot.arm.set_ee_pose_components(0.24, -0.18, -0.081, 1, 1.5)
                bot.gripper.close()
                bot.gripper.set_pressure(1.0)
                # bot.arm.go_to_home_pose()
                bot.arm.set_ee_pose_components(0.24, -0.18, 0.081, 1, 1.5)
                bot.arm.set_ee_pose_components(0.18, -0.05, 0.084, 1, 1.5)
                bot.arm.set_ee_pose_components(0.18, -0.05, -0.084, 1, 1.5)
                bot.gripper.open()
                # bot.arm.go_to_home_pose()
                bot.arm.go_to_sleep_pose()
            elif computer_move==4:
                # bot.arm.go_to_home_pose()
                bot.arm.set_ee_pose_components(0.12, -0.23, -0.1, 0, 1.5)
                bot.gripper.close()
                bot.gripper.set_pressure(1.0)
                # bot.arm.go_to_home_pose()
                bot.arm.set_ee_pose_components(0.12, -0.23, 0.1, 0, 1.5)
                bot.arm.set_ee_pose_components(0.18, -0.05, 0.084, 1, 1.5)
                bot.arm.set_ee_pose_components(0.24, -0.04, -0.080, 1, 1.5)
                bot.gripper.open()
                # bot.arm.go_to_home_pose()
                bot.arm.go_to_sleep_pose()
            elif computer_move==5:
                # bot.arm.go_to_home_pose()
                bot.arm.set_ee_pose_components(0.17, -0.24, -0.1, 0.3, 1.5)
                bot.gripper.close()
                bot.gripper.set_pressure(1.0)
                # bot.arm.go_to_home_pose()
                bot.arm.set_ee_pose_components(0.17, -0.24, 0.1, 0.3, 1.5)
                bot.arm.set_ee_pose_components(0.30, -0.05, 0.084, 1, 1.5)
                bot.arm.set_ee_pose_components(0.30, -0.05, -0.084, 1, 1.5)
                bot.gripper.open()
                # bot.arm.go_to_home_pose()
                bot.arm.go_to_sleep_pose()
            elif computer_move==6:
                # bot.arm.go_to_home_pose()
                bot.arm.set_ee_pose_components(0.23, -0.24, -0.1, 0.3, 1.5)
                bot.gripper.close()
                bot.gripper.set_pressure(1.0)
                # bot.arm.go_to_home_pose()
                bot.arm.set_ee_pose_components(0.23, -0.24, 0.1, 0.3, 1.5)
                bot.arm.set_ee_pose_components(0.18, -0.12, 0.084, 1, 1.5)
                bot.arm.set_ee_pose_components(0.18, -0.12, -0.084, 1, 1.5)
                bot.gripper.open()
                # bot.arm.go_to_home_pose()
                bot.arm.go_to_sleep_pose()
            elif computer_move==7:
                # bot.arm.go_to_home_pose()
                bot.arm.set_ee_pose_components(0.29, -0.24, -0.1, 0.3, 1.5)
                bot.gripper.close()
                bot.gripper.set_pressure(1.0)
                # bot.arm.go_to_home_pose()
                bot.arm.set_ee_pose_components(0.29, -0.24, 0.1, 0.3, 1.5)
                bot.arm.set_ee_pose_components(0.24, -0.11, 0.084, 1, 1.5)
                bot.arm.set_ee_pose_components(0.24, -0.11, -0.084, 1, 1.5)
                bot.gripper.open()
                # bot.arm.go_to_home_pose()
                bot.arm.go_to_sleep_pose()
            elif computer_move==8:
                # bot.arm.go_to_home_pose()
                bot.arm.set_ee_pose_components(0.115, -0.29, -0.1, 0, 1.5)
                bot.gripper.close()
                bot.gripper.set_pressure(1.0)
                # bot.arm.go_to_home_pose()
                bot.arm.set_ee_pose_components(0.115, -0.29, 0.1, 0, 1.5)
                bot.arm.set_ee_pose_components(0.30, -0.12, 0.084, 1, 1.5)
                bot.arm.set_ee_pose_components(0.30, -0.12, -0.084, 1, 1.5)
                bot.gripper.open()
                # bot.arm.go_to_home_pose()
                bot.arm.go_to_sleep_pose()
            else:
                print("Invalid Position")
 
    def check_winner(self):
        result = check_game_over(self.board)
        if result != 'Not over':
            if result == 'X':
                self.game_over_message("Player X wins!")
            elif result == 'O':
                self.game_over_message("Player O wins!")
            else:
                self.game_over_message("It's a tie!")
 
    def game_over_message(self, message):
        messagebox.showinfo("Game Over", message)
        self.root.quit()
 
    def switch_turn(self):
        self.turn = 'O' if self.turn == 'X' else 'X'
 
    def update_camera_frame(self, frame):
        # Convert the frame to RGB color space
        img_tk = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        # Create an ImageTk object from the converted frame
        img_tk = Image.fromarray(img_tk)
        img_tk = ImageTk.PhotoImage(image=img_tk)
        # Update the canvas with the new image
        self.canvas.create_image(0, 0, anchor=tk.NW, image=img_tk)
        self.canvas.image = img_tk
        self.root.update()
 
# Create the TicTacToeGUI instance before starting the loop
tic_tac_toe_gui = TicTacToeGUI(tk.Tk())
 
# Start the camera feed
cap = cv2.VideoCapture(6)
 
while True:
    ret, frame = cap.read()
    # if ret:
 
    #     frame=cv2.rotate(frame,cv2.ROTATE_90_CLOCKWISE)
    # else:
    #     break
    if not ret:
        break
 
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    blurred = cv2.GaussianBlur(gray, (5, 5), 0)
    edges = cv2.Canny(blurred, 10, 10)
    contours, _ = cv2.findContours(edges.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
 
    min_area = 100
    min_aspect_ratio = 0.8
    max_aspect_ratio = 1.2
    filtered_contours = []
    for contour in contours:
        area = cv2.contourArea(contour)
        if area > min_area:
            x, y, w, h = cv2.boundingRect(contour)
            aspect_ratio = float(w) / h
            if min_aspect_ratio < aspect_ratio < max_aspect_ratio:
                filtered_contours.append((x, y, w, h))
    
    for i, (x, y, w, h) in enumerate(filtered_contours):
        if i < 9 :
 
            center_x = x + w // 2
            center_y = y + h // 2
            cv2.circle(frame, (center_x, center_y), 5, (255, 255, 255), -1)
            # row = int(center_y / (frame_height / 3))
            # col = int(center_x / (frame_width / 3))
            
            row = i // 3
            col = i % 3
        
            box_name = get_box_name(row, col)
            
            color = get_color(frame, center_x, center_y)
            if box_name == "2":
                row = 2
                col = 0
            if box_name == "0":
                row = 2
                col = 2
            if box_name == "1":
                row = 2
                col = 1
            if box_name == "3":
                row = 1
                col = 0
            if box_name == "4":
                row = 1
                col = 1
            if box_name == "5":
                row = 1
                col = 2
            if box_name == "6":
                row = 0
                col = 0
            if box_name == "7":
                row = 0
                col = 1
            if box_name == "8":
                row = 0
                col = 2
            if color=="X":
                print("box_name -", box_name)
                print("row- ", row, "col- ", col)
                tic_tac_toe_gui.make_move(row, col)
                # tic_tac_toe_gui.make_computer_move()
            # cv2.putText(frame, f"(Row: {row}, Col: {col})", (center_x, center_y + 20), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2)
            cv2.putText(frame, f"Box: {box_name}, Color: {color}", (x, y - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2)
            print("Box:", box_name, "Center:", (center_x, center_y), "Color:", color)
            # Update the GUI button corresponding to the detected object
            # if color == 'X':
                # tic_tac_toe_gui.make_move(row, col)
 
    tic_tac_toe_gui.update_camera_frame(frame)
 
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break
 
cap.release()
cv2.destroyAllWindows()