import cv2
import numpy as np

# Function to get the name of each box based on row and column index
def get_box_name(row, col):
    letters = ['a', 'b', 'c']
    numbers = ['1', '2', '3']
    if 0 <= row < len(numbers) and 0 <= col < len(letters):
        return letters[col] + numbers[row]
    else:
        return "Invalid Index"

# Function to determine the color of an object based on its centroid
def get_color(frame, x, y):
    # Extract region around centroid for color detection
    region = frame[y - 5:y + 5, x - 5:x + 5]
    # Convert region to HSV color space
    hsv = cv2.cvtColor(region, cv2.COLOR_BGR2HSV)
    
    lower_yellow = np.array([20, 100, 100])
    upper_yellow = np.array([30, 255, 255])
    lower_green = np.array([50, 20, 20])
    upper_green = np.array([100, 255, 255])
    
    # Threshold the HSV image to get only green color
    mask_green = cv2.inRange(hsv, lower_green, upper_green)
    mask_yellow = cv2.inRange(hsv, lower_yellow, upper_yellow)
   
    if cv2.countNonZero(mask_yellow) > 0:
        return "X"
    elif cv2.countNonZero(mask_green) > 0:
        return "O"
    else:
        return ""

# Capture live video from camera
cap = cv2.VideoCapture(6)

# Define grid dimensions
rows, cols = 3, 3

while True:
    # Read frame from camera
    ret, frame = cap.read()
    if not ret:
        break

    # Convert frame to grayscale
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

    # Apply Gaussian blur to reduce noise
    blurred = cv2.GaussianBlur(gray, (5, 5), 0)

    # Apply Canny edge detection
    edges = cv2.Canny(blurred, 10, 10)

    # Find contours
    contours, _ = cv2.findContours(edges.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    # Filter contours by area and aspect ratio
    min_area = 100
    min_aspect_ratio = 0.8
    max_aspect_ratio = 1.2
    filtered_contours = []
    for contour in contours:
        area = cv2.contourArea(contour)
        if area > min_area:
            x, y, w, h = cv2.boundingRect(contour)
            aspect_ratio = float(w) / h
            if min_aspect_ratio < aspect_ratio < max_aspect_ratio:
                filtered_contours.append((x, y, w, h))

    # Draw bounding boxes and extract coordinates
    for i, (x, y, w, h) in enumerate(filtered_contours):
        # Calculate center coordinates
        center_x = x + w // 2
        center_y = y + h // 2
        # Draw circle at center
        # cv2.circle(frame, (center_x, center_y), 5, (0, 255, 0), -1)
        cv2.circle(frame, (center_x, center_y), 5, (255,255,255), -1)
        # Get box name based on row and column index
        row = i // cols
        col = i % cols
        box_name = get_box_name(row, col)
        # Get color of the object
        color = get_color(frame, center_x, center_y)
        # Display box name, center coordinates, and color on the frame
        # cv2.putText(frame, f"{box_name}: ({center_x}, {center_y}), Color: {color}", (x, y - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 0, 0), 2)
        cv2.putText(frame, f", Color: {color}", (x, y - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 0, 0), 2)
        # Print box name, center coordinates, and color
        print("Box:", box_name, "Center:", (center_x, center_y), "Color:", color)

    # Display the frame
    cv2.imshow('Frame', frame)

    # Break the loop when 'q' is pressed
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

# Release the camera and close windows
cap.release()
cv2.destroyAllWindows()
