#!/usr/bin/env python
# coding: utf-8


def CausalStrength(df, treatment_var, outcome_var, edge_df):
    
    # Creating a graph object from dataframe having edges
    G = nx.from_pandas_edgelist(edge_df, 'from', 'to', edge_attr=None, create_using=None)
    
    # Path to graph 
    path_to_graph = "../Sample_Models/graph.dot"
    
    # Writing the graph as a .dot file
    write_dot(G, path_to_graph)
    
    # Creating a causal model from data and given common causes
    model = CausalModel(
        data = df,
        treatment=treatment_var,
        outcome=outcome_var,
        graph=path_to_graph
        )

    # Identifying the causal effect
    identified_estimand = model.identify_effect(proceed_when_unidentifiable=True)

    # Estimating the causal effect and comparing it with Average Treatment Effect
    estimate = model.estimate_effect(identified_estimand,
                                     method_name="backdoor.linear_regression"
                                    )
    return(estimate.value)
    # return("success")

