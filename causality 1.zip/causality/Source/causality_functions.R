
################################################################################################
# Title : Utilities for Causal structure learning and inference
# Created : October 15, 2019
# Author : Animesh Danayak, Gayathri Anil, Sunuganty Achyut Raj
# Version : 19.11.02
# Description : Contains all the functions for plotting networks, defining colors for Observable, Target and Latent variables
#
# Revisions
################################################################################################


#------------------------------------------------------------------------------------------------------------------------------
# Function to install and load libraries
#------------------------------------------------------------------------------------------------------------------------------

# install packages if not present
list.of.packages <- c("bnlearn", "DT", "caret", "visNetwork", "knitr", "dplyr", "data.table", 
                      "stringr", "lubridate", "igraph", "anytime", "zoo", "ggplot2", "lmtest", 
                      "parallel", "purrr", "reshape2", "entropy", "tidyr", "glmnet", "mlbench", 
                      "DataExplorer", "corrplot", "pcalg", "NlinTS", "vars", "reticulate", "corrr", 
                      "qgraph", "tidyverse", "readr", "qwraps2", "bnstruct", "cowplot", "magrittr",
                      "qwraps2", "plyr", "network", "multiplex", "dils", "kableExtra", "ggcorrplot", 
                      "polycor", "moments", "Hmisc")
new.packages <- list.of.packages[!(list.of.packages %in% installed.packages()[,"Package"])]
if(length(new.packages)) install.packages(new.packages, repos = "https://cran.rstudio.com")
# initialize libraries
library(bnlearn)
library(bnstruct)
library(DT)
library(caret)
library(visNetwork)
library(knitr)
library(dplyr)
library(data.table)
library(stringr)
library(lubridate)
library(igraph)
library(anytime)
library(zoo)
library(ggplot2)
# library(cowplot)
library(lmtest)
library(parallel)
library(readr)
library(purrr)
library(reshape2)
library(entropy)
library(tidyr)
library(glmnet)
library(mlbench)
library(DataExplorer)
library(corrplot)
library(pcalg)
library(NlinTS)
library(vars)
library(reticulate)
library(corrr)
library(qgraph)
library(magrittr)
library(qwraps2)
library(plyr)
#library(analysisPipelines)
#library(multiplex)
library(network)
#library(dils)
library(kableExtra)
library(ggcorrplot)
library(polycor)
library(moments)
library(Hmisc)

reticulate::use_python('/usr/bin/python3', required = T)

#------------------------------------------------------------------------------------------------------------------------------
# Load Utilities
#------------------------------------------------------------------------------------------------------------------------------





#------------------------------------------------------------------------------------------------------------------------------
# Function to visualize Bayesian Networks
#------------------------------------------------------------------------------------------------------------------------------

# Plotting function
plotNetwork <- function (networkStructure) {
  edge_df <- data.frame(networkStructure$arcs)
  edge_df$strength <- 1
  node_df <- data.frame(id=names(networkStructure$nodes),label=names(networkStructure$nodes))
  node_df$group <- ifelse(node_df$id %in% target_list,"Target",
                          ifelse(node_df$id %in% latent_list, "Latent","Observable")) 
  
  
  #------------------------------------------------------------------------------------------------------------------------------
  # Function to define colors for Observable, Target and Latent variables
  #------------------------------------------------------------------------------------------------------------------------------
  
  
  lnodes <- data.frame(label = c("Observable", "Target",  "Latent"), 
                       shape = c("dot"), color = c("#A1AEFF","#ff4d4d",  "#F8D000"),
                       title = "Variable Type") 
  
  visNetwork(node_df, edge_df) %>% 
    visGroups(groupname = "Observable", color = "#A1AEFF", shadow=T) %>%
    visGroups(groupname = "Latent", color = "#F8D000", shadow=T) %>%
    visGroups(groupname = "Target", color = "#ff4d4d", shadow=T) %>%
    visLegend(addNodes = lnodes, position = "right", 
              zoom = F, useGroups = F, main ="Variable Type")%>%
    visNodes(font = list(size =18)) %>%
    visEdges(arrows=list(to=list(enabled = T, scaleFactor = 0.25)), 
             widthConstraint = 1.2,
             length = c(3)) %>%
    visOptions(highlightNearest = TRUE, nodesIdSelection = TRUE) %>%
    visLayout(randomSeed = 6, improvedLayout = T) %>% 
    
    # To stop auto update and make nodes sticky
    visPhysics(enabled = F) %>%
    visInteraction(navigationButtons = TRUE)
}



#------------------------------------------------------------------------------------------------------------------------------
# Function to specify if one element is NOT IN a particular element
#------------------------------------------------------------------------------------------------------------------------------

`%!in%` <- function(a,b) ! a %in% b


#------------------------------------------------------------------------------------------------------------------------------
# Function to identify edges using MAPE
#------------------------------------------------------------------------------------------------------------------------------

MAPE <- function(actual, pred){
  # actual = ifelse(actual == 0, 0.00000001, actual)
  removeInd <- which(actual ==  0)
  if(length(removeInd) > 0){
    pe <- abs(actual[-removeInd]-pred[-removeInd])/actual[-removeInd]
    #print("Mape calculated without the zero actuals")  
  }else {
    pe <- abs(actual-pred)/actual
  }
  mean(pe)
}


#------------------------------------------------------------------------------------------------------------------------------
# Descriptive statistics for EDA - Numeric variables
#------------------------------------------------------------------------------------------------------------------------------


numericStats <- function(data){
  num_desc_list <- lapply(data, function(x) {
    
    ## calculating different statistics for numerical continuous variables
    min_val <-  min(x, na.rm = T) %>% round(3)
    max_val <-  max(x, na.rm = T) %>% round(3)
    mean_val <- mean(x, na.rm = T) %>% round(3)
    median_val <- stats::median(x, na.rm = T) %>% round(3)
    sd_val <- stats::sd(x, na.rm = T) %>% round(3)
    unique_val <- unique(x) %>% length()
    no_of_na <- is.na(x) %>% sum()
    no_of_lines <- x %>% length()
    data_skewness <- moments::skewness(x, na.rm = TRUE) %>% round(3)
    data_kurtosis <- moments::kurtosis(x, na.rm = TRUE) %>% round(3)
    coefficient_of_variation <- format(round(((stats::sd(x, na.rm = T)/(mean(x, na.rm = T)))*100), 3), nsmall = 3) #%>% round(3)
    library(MASS)
    # M_estimator <- huber(x, k = 1.5, tol = 1e-06) #M estimator statistics
    # standard_error_of_the_mean  <- sd_val/sqrt(length(x)) %>% round(3) #Standard error of the mean
    
    data.frame(
      "N" = no_of_lines,
      "Unique" = unique_val,
      "MissingPercentage" = as.numeric(format(round(((no_of_na/nrow(data))*100), 3), nsmall = 3)),
      "Min" = min_val,
      "Max" = max_val,
      "Mean" = mean_val,
      "Median" = median_val,
      "SD" = sd_val,
      "Skewness" = data_skewness,
      "Kurtosis" = data_kurtosis,
      "Coefficient of Variation" = coefficient_of_variation,
      "MissingRows" = no_of_na
      # "M Estimator" = M_estimator,
      # "Mean Std Error" = standard_error_of_the_mean
      
    )
  })
  
  data_sum <- do.call(rbind, num_desc_list)
  data_sum <- cbind(data.frame(ColumnName = rownames(data_sum)), data_sum)
  rownames(data_sum) <- NULL
  return(data_sum)
}



#------------------------------------------------------------------------------------------------------------------------------
# Descriptive statistics for EDA - Categorical variables
#------------------------------------------------------------------------------------------------------------------------------


categoricStats <- function(data){
  cat_desc_list <- lapply(data, function(x) {
    
    mat_cat <- table(x)
    mode <- names(mat_cat)[mat_cat == max(mat_cat)]
    mode <- ifelse(length(mode) > 1, "No mode", mode)
    uniq_val <- length(unique(x))
    total_rows <- length(x)
    missing_perc <- round((sum(is.na(x))*100/total_rows), 3)
    missTable <- data.frame(total_rows,
                            uniq_val,
                            round(missing_perc,2),
                            mode)
    colnames(missTable) <- c("N", "Unique", "% of Missing Values", "Mode")
    return(missTable)
  })
  
  data_sum <- do.call(rbind, cat_desc_list)
  data_sum <- cbind(data.frame(ColumnName = rownames(data_sum)), data_sum)
  rownames(data_sum) <- NULL
  return(data_sum)
}

#------------------------------------------------------------------------------------------------------------------------------
# Function for running Granger Test
#------------------------------------------------------------------------------------------------------------------------------

get_granger <- function(x,y,data){
  tryCatch({
    x = as.character(x)
    y = as.character(y)
    res <- grangertest(data[[x]],data[[y]],order=10)
    return(res)
  },error=function(e){return(e[[1]])})
}

#------------------------------------------------------------------------------------------------------------------------------
# Function for compute size of nodes - for visualising causal structures
#------------------------------------------------------------------------------------------------------------------------------

nodeSize <- function(edgeList, operation_variables){
  nodes <-
    edgeList %>%
    dplyr::group_by(to) %>%
    dplyr::summarise(size = dplyr::n()) %>%
    merge(data.frame(to = operation_variables), all.y=TRUE) %>%
    dplyr::mutate(label = to, size = ifelse(is.na(size), 10, (10 + (size)*5)))
  return(nodes)
}

#------------------------------------------------------------------------------------------------------------------------------
# Function to compare structures learned using various algorithms
#------------------------------------------------------------------------------------------------------------------------------

compareStructures <- function(operation_vars, algos){
  # operation_vars
  num_algos <- length(algos)
  # algos <- c("pc", "mmhc", "ges", "hc")
  
  # Creating complete list of combos
  compare_df <- 
    data.frame(from = operation_vars) %>% 
    merge(data.frame(to = operation_vars)) %>% 
    dplyr::mutate(key = ifelse(as.numeric(from) < as.numeric(to),  
                               paste(from, to), 
                               paste(to, from))) %>% 
    filter(!duplicated(key)) %>% 
    dplyr::select(-key)
  
  # Adding algo columns denoting the presence or absence of an edge, along with direction (+1 / -1)
  lapply(algos, function(algo_name){
    
    edge_list <- get(paste0("edge_list_", algo_name))
    
    edge_list$forward <- 1
    edge_list$reverse <- -1
    
    compare_df <<- 
      compare_df %>% 
      merge(edge_list[, c("from", "to", "forward")], by = c("from", "to"), all.x = TRUE) %>% 
      left_join(edge_list[, c("from", "to", "reverse")], by = c("from" = "to", "to" = "from")) 
    
    compare_df[, algo_name] <<- ifelse(is.na(coalesce(compare_df$forward, compare_df$reverse)), 0, coalesce(compare_df$forward, compare_df$reverse))
    compare_df <<- compare_df %>% dplyr::select(-c("reverse", "forward")) 
  })
  
  # Temporary variable
  temp_df <- compare_df %>% dplyr::select(algos)
  
  # Calculating gini impurity score
  lapply(1:nrow(compare_df), function(x){
    minus_1 <- (unname(rowSums(temp_df[x, ] == -1))/num_algos)^2
    plus_1 <- (unname(rowSums(temp_df[x, ] == 1))/num_algos)^2
    zero <- (unname(rowSums(temp_df[x, ] == 0))/num_algos)^2
    compare_df[x, "gini_impurity"] <<- 1 - (minus_1 + plus_1 + zero)
  })
  
  return(compare_df)
  
}


#------------------------------------------------------------------------------------------------------------------------------
# Function to create a bnstruct dataset
#------------------------------------------------------------------------------------------------------------------------------


createBNDataset <- function(data, num_time_steps, operation_vars, quantile_levels){
  # Setting the quantile parameter and setting time steps
  num_quantile <- 8
  new_names = operation_vars
  input_sub2 <- data.table(data)
  
  ## DO THIS
  if(num_time_steps==0){
    print("Invalid time step. Please put time step greater than 0")  
  }else if(num_time_steps!=1){
    x <- purrr::map(c(1:(num_time_steps-1)), function(x){
      new_names <<- append(new_names,paste0("lead_", x,"_",operation_vars))
      cols_select = new_names[c(((as.numeric(as.character(x))-1)*ncol(data)+1):((as.numeric(as.character(x)))*ncol(data)))]
      cols_create <- tail(new_names[new_names %!in% cols_select], ncol(data))
      input_sub2[,(cols_create):= shift(.SD, type="lead"), .SDcols= cols_select]
      input_sub2 <- input_sub2[,c(operation_vars, cols_create ),with=FALSE]
    })
  }
  
  input_sub2 <- as.data.frame(input_sub2)
  data <- na.omit(input_sub2)
  
  # Data preparation - Specifying the discreteness of columns
  discrete_value <- sapply(data, function(col){
    return(ifelse(is.numeric(col), 'c','d'))
  },USE.NAMES = FALSE)
  
  # Data preparation 
  ## Specifying the node sizes for continuous columns 
  if (is.null(quantile_levels)){
    node_size <- rep(num_quantile, ncol(data))
  } else {
    node_size <- quantile_levels
  }
  
  ## Getting the levels of discrete columns 
  for (i in seq_along(data)){
    if (discrete_value[i] == "d"){
      data[[i]] <- as.factor(as.character(data[[i]]))
      node_size[i] <- length(levels(data[[i]]))
      data[[i]] <- as.integer(data[[i]] )
    }
  }
  ### DO THIS
  # seq_along(data) %>% map(~{
  #   data <- .
  #   if (discrete_value[i] == "d"){
  #     data <- as.factor(as.character(data[[i]]))
  #     node_size <- length(levels(data[[i]]))
  #     data2 <- as.integer(data[[i]] )
  #   }
  #   list(data1=data,node_size=node_size,data2=data2)
  # })
  
  # Writing data into a file and column name along with discreteness vector and node.size vector into header file (as required by the package)
  col_length <- length(discrete_value)/num_time_steps
  input.header <- paste(paste0('"',colnames(data)[1:col_length],'"'),collapse = " ")
  headerfcon <- file("../Downloads/input.header",open = "wa+")
  writeLines(input.header , headerfcon)
  writeLines(paste0(node_size[1:col_length],collapse = " "), headerfcon)
  writeLines(paste0(toupper(as.character(discrete_value[1:col_length])), collapse = " "), headerfcon)
  close(headerfcon)
  
  write.table(data, file = "../Downloads/input.data", sep = " ", row.names = F, col.names = F)
  
  # Creating the dataset as input (BNDataset) to the network
  inputbn <- BNDataset("../Downloads/input.data","../Downloads/input.header",
                       starts.from=1,
                       num.time.steps=num_time_steps)
  return(inputbn)
  
}

#------------------------------------------------------------------------------------------------------------------------------
# Function to create a graph object to compare the structures learned by various algorithms
#------------------------------------------------------------------------------------------------------------------------------


comparisonGraph <- function(comparison_df, num_algos){
  
  num_row <- nrow(comparison_df)
  num_col <- ncol(comparison_df)
  
  # Creating a temporary df with just algos
  temp_df <- comparison_df %>% dplyr::select(-c("from", "to", "gini_impurity"))
  
  # Adding sum columns to give as weights
  comparison_df <- 
    comparison_df %>% 
    mutate(plain_sum=unlist(lapply(1:num_row, function(row){return(sum(temp_df[row, ]))}))) 
  
  # Setting edge direction and width
  lapply(1:num_row, function(x){
    if(comparison_df[x, "plain_sum"] < 0)
    {
      temp <- comparison_df[x, "from"]
      comparison_df[x, "from"] <<- comparison_df[x, "to"]
      comparison_df[x, "to"] <<- temp
    }
    
  })
  
  
  
  # Computing adjacency matrix from list of edges
  edge_list <- 
    comparison_df %>%
    dplyr::select(c(from, to)) %>% 
    mutate(equal_weight = 1) %>% 
    dplyr::select(from, to, equal_weight)
  
  adj_matrix <- edge_list %>% 
    dils::AdjacencyFromEdgelist(check.full = TRUE)
  
  # Creating a temp dataframe to reorder comparison dataframe
  temp_df <- 
    adj_matrix$nodelist %>% 
    merge(adj_matrix$nodelist) %>% 
    filter(x!=y) %>% 
    `colnames<-`(c("to", "from")) %>% 
    merge(edge_list, by = c("from", "to"), all.y = TRUE)
  
  comparison_df <- comparison_df[order(comparison_df$from,comparison_df$to), ][ order(order(temp_df$from,temp_df$to)), ]
  
  
  
  # Creating a graph object from the adjacency matrix
  graph_obj <- igraph::graph_from_adjacency_matrix(matrix(adj_matrix$adjacency, 
                                                          dimnames = list(adj_matrix$nodelist, adj_matrix$nodelist), 
                                                          nrow = nrow(adj_matrix$adjacency)))
  
  # Assigning labels to the edges in the graph
  
  scaling_factor <- 1 - (((num_algos-1) * (3-1)) / (num_algos^2)) # where 3 is the number of levels : -1, 0, +1
  
  E(graph_obj)$width <- 1 + ((comparison_df$gini_impurity - scaling_factor)*(-1/scaling_factor))*8
  
  visIgraph(graph_obj, physics = TRUE) %>% visPhysics(solver = "forceAtlas2Based", 
                                                      forceAtlas2Based = list(gravitationalConstant = -500, 
                                                                              centralGravity = 0.01))
  return(graph_obj)
  
}
