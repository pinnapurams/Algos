#!/usr/bin/env python
# coding: utf-8

# In[1]:


def refutation(df, treatment_var, outcome_var, edge_df, method):

    # Creating a graph object from dataframe having edges
    G = nx.from_pandas_edgelist(edge_df, 'from', 'to', edge_attr=None, create_using=None)
    
    # Path to graph 
    path_to_graph = "../Sample_Models/graph.dot"
    
    # Writing the graph as a .dot file
    write_dot(G, path_to_graph)    
    
    # Creating a causal model from data and given common causes
    model = CausalModel(
        data = df,
        treatment=treatment_var,
        outcome=outcome_var,
        graph=path_to_graph,
        proceed_when_unidentifiable = True)

    identified_estimand = model.identify_effect(proceed_when_unidentifiable = True)

    estimate = model.estimate_effect(identified_estimand,
                                     method_name="backdoor.linear_regression")
    
    if (method == "random_common_cause"):
        strength = model.refute_estimate(identified_estimand, 
                                         estimate, 
                                         method_name="random_common_cause")
        
    elif (method == "placebo_treatment_refuter"):
        strength = model.refute_estimate(identified_estimand, 
                                         estimate,
                                         method_name="placebo_treatment_refuter", 
                                         placebo_type="permute")
        
    else: 
        strength = model.refute_estimate(identified_estimand, 
                                         estimate,
                                         method_name="data_subset_refuter", 
                                         subset_fraction=0.9)
    
    
    strength = str(strength).split("\n")
    strength[0] = strength[0].strip()
    strength[1] = float(re.findall("-?\d+\.\d+", strength[1])[0])
    strength[2] = float(re.findall("-?\d+\.\d+", strength[2])[0])

    #validation_df = validation_df.append({'from': treatment_var, 'to' : outcome_var, 'method' : method, 'pre_strength' : estimate.value, 'post_strength' : strength[2]}, ignore_index=True)
    
    return(strength[2])

